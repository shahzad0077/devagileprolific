@php
$var_objective = "Backlog";
@endphp
@extends('components.main-layout')
<title>Backlogs</title>
@section('content')
<style>

</style>

 <div class="d-flex flex-column flex-root">
        <!-- begin topbar -->
        <!--begin::Page-->
        <div class="page d-flex flex-row flex-column-fluid">
            <!-- begin Sidebar -->
   
            <!-- end Sidebar -->
            <div class="content d-flex flex-column flex-column-fluid">
                <!-- begin breadcrums -->
                <!-- end breadcrums -->
                <!-- begin page Content -->
                <div class="container-fluid py-5 w-96" id="assign-epic">
                    <div class="row">
                        <div class="col-md-12 p-0">
                            <div class="card">
                                <div class="card-body p-10">
                                
                                  @if (session('message'))
                                  <div class="alert alert-success mt-1" role="alert">
                                  {{ session('message') }}
                                  </div>
                                   @endif
                                           
                                    @foreach($Backlog as $backlog)       
                                    <div class="backlog-item">
                                        <div class="sub-item">
                                            <div class="d-flex flex-row align-items-center">
                                                <div>
                                                     <label class="form-checkbox">
                                                    <input type="checkbox" class="checkbox" @if($backlog->epic_end_date == '') disabled @endif value="{{$backlog->id}}" @if($backlog->assign_status == 1)  disabled @endif>
                                                    <span class="checkbox-label"></span>
                                                  </label>
                                                </div>
                                                <div >
                                                    <span class="ml-3">{{$backlog->epic_title}}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="sub-item">
                                            {{$organization->value_name}} <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                                  <path d="M4.72421 14.1377C4.29212 14.1377 3.88837 13.989 3.59796 13.7127C3.22962 13.3656 3.05254 12.8415 3.11629 12.2748L3.37837 9.9798C3.42796 9.54772 3.69004 8.97397 3.99462 8.6623L9.81004 2.50688C11.2621 0.969799 12.778 0.9273 14.315 2.37938C15.8521 3.83147 15.8946 5.3473 14.4425 6.88438L8.62712 13.0398C8.32962 13.3585 7.77712 13.656 7.34504 13.7269L5.06421 14.1165C4.94379 14.1235 4.83754 14.1377 4.72421 14.1377ZM12.0838 2.3723C11.5384 2.3723 11.0638 2.7123 10.5821 3.2223L4.76671 9.3848C4.62504 9.53355 4.46212 9.88772 4.43379 10.0931L4.17171 12.3881C4.14337 12.6219 4.20004 12.8131 4.32754 12.9335C4.45504 13.054 4.64629 13.0965 4.88004 13.061L7.16087 12.6715C7.36629 12.6361 7.70629 12.4519 7.84796 12.3031L13.6634 6.14772C14.5417 5.21272 14.8605 4.34855 13.5784 3.14438C13.0117 2.59897 12.523 2.3723 12.0838 2.3723Z" fill="#292D32"/>
                                                  <path d="M13.0824 8.06722C13.0683 8.06722 13.047 8.06722 13.0329 8.06722C10.8229 7.84764 9.04495 6.16889 8.70495 3.97305C8.66245 3.68264 8.86078 3.41347 9.1512 3.36389C9.44162 3.32139 9.71078 3.51972 9.76037 3.81014C10.0295 5.5243 11.4179 6.8418 13.1462 7.0118C13.4366 7.04014 13.6491 7.30222 13.6208 7.59264C13.5854 7.8618 13.3516 8.06722 13.0824 8.06722Z" fill="#292D32"/>
                                                  <path d="M15.6748 16.4255H2.9248C2.63439 16.4255 2.39355 16.1847 2.39355 15.8943C2.39355 15.6039 2.63439 15.363 2.9248 15.363H15.6748C15.9652 15.363 16.2061 15.6039 16.2061 15.8943C16.2061 16.1847 15.9652 16.4255 15.6748 16.4255Z" fill="#292D32"/>
                                                </svg>
                                        </div>
                                     
                                        <div class="sub-item">
                                            @if($backlog->epic_end_date != '')
                                            {{ \Carbon\Carbon::parse($backlog->epic_start_date)->format('M d')}} - {{ \Carbon\Carbon::parse($backlog->epic_end_date)->format('M d')}}
                                            @else
                                            Epic Date Not Selected
                                            @endif
                                        </div>
                                        
                                      <div class="sub-item">
                                            <div class="dropdown">
                                              <button class="badge badge-pill badge-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                {{$backlog->epic_status}} <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                                  <path d="M7.39997 9.91113C7.02081 9.91113 6.64164 9.76488 6.35456 9.4778L2.82289 5.94613C2.66581 5.78905 2.66581 5.52905 2.82289 5.37196C2.97997 5.21488 3.23997 5.21488 3.39706 5.37196L6.92872 8.90363C7.18872 9.16363 7.61122 9.16363 7.87122 8.90363L11.4029 5.37196C11.56 5.21488 11.82 5.21488 11.9771 5.37196C12.1341 5.52905 12.1341 5.78905 11.9771 5.94613L8.44539 9.4778C8.15831 9.76488 7.77914 9.91113 7.39997 9.91113Z" fill="white"/>
                                                </svg>
                                              </button>
                                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item" href="#">Todo</a>
                                                <a class="dropdown-item" href="#">Pending</a>
                                                <a class="dropdown-item" href="#">Done</a>
                                              </div>
                                            </div>
                                        </div>
                                        <div class="sub-item">
                                            <div class="d-flex flex-column">
                                                <div class="ml-auto">
                                                    {{$backlog->progress}}%
                                                </div>
                                                <div>
                                                    <div class="progress">
                                                      <div class="progress-bar" role="progressbar" style="width: {{$backlog->progress}}%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="sub-item">
                                            <button class="btn-circle btn-tolbar" data-toggle="modal" data-target="#create{{$backlog->id}}">
                                                <img src="{{asset('assets/images/icons/edit.svg')}}" data-toggle="tooltip" data-placement="top" data-original-title="Edit">
                                            </button>
                                            <button class="btn-circle btn-tolbar">
                                                <img src="{{asset('assets/images/icons/delete.svg')}}" data-toggle="tooltip" data-placement="top" data-original-title="Delete">
                                            </button>
                                        </div>
                                    </div>
                            <div class="modal fade" id="create{{$backlog->id}}" tabindex="-1" role="dialog" aria-labelledby="create-epic" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content" style="width: 526px !important;">
                                    <div class="modal-header">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h5 class="modal-title" id="create-epic">Update Backlog Epic</h5>
                                            </div>
                                            <div class="col-md-12">
                                                <p>Fill out the form, submit and hit the save button.</p>
                                            </div>
                                              <div id=""  role="alert"></div>
                                            <span id="" class="ml-3 text-danger"></span>
                                        </div>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <img src="{{asset('assets/images/icons/minus.svg')}}">
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form class="needs-validation" action="{{url('update-backlog-epic')}}" method="POST" >
                                        @csrf
                                            <input type="hidden" name="backlog_id" value="{{$backlog->id}}">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                    <div class="form-group mb-0">
                                                        <input type="text" class="form-control" value="{{$backlog->epic_title}}" name="epic_name" id="" required>
                                                        <label for="objective-name">Epic Title</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-xl-6">
                                                    <div class="form-group mb-0">
                                                        <input type="date" class="form-control"  name="epic_start_date" value="{{$backlog->epic_start_date}}">
                                                        <label for="start-date">Start Date</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-xl-6">
                                                    <div class="form-group mb-0">
                                                        <input type="date" class="form-control"  name="epic_end_date" value="{{$backlog->epic_end_date}}">
                                                        <label for="end-date">End Date</label>
                                                    </div>
                                                </div>
                                                  <div class="col-md-12 col-lg-12 col-xl-12">
                                                    <div class="form-group mb-0">
                                                       <select class="form-control" name="epic_status">
                                                            <option value="To Do">To Do</option>
                                                          <option value="In progress">In Progress</option>
                                                           <option value="Done">Done</option>
                        
                                                       </select>
                                                        <label for="small-description">Status</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                    <div class="form-group mb-0">
                                                        <input type="text" class="form-control" value="{{$backlog->epic_detail}}"  name="epic_description">
                                                        <label for="small-description">Small Description</label>
                                                    </div>
                                                </div>
                                                
                                        
                                                
                                                <div class="col-md-12">
                                                    <button class="btn btn-primary btn-lg btn-theme btn-block ripple mt-3"  type="submit">Update</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end page content -->
            </div>
        </div>
    </div>
    
  <div class="modal fade" id="create-backlog-epic" tabindex="-1" role="dialog" aria-labelledby="create-epic" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 526px !important;">
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="modal-title" id="create-epic">Create Backlog Epic</h5>
                    </div>
                    <div class="col-md-12">
                        <p>Fill out the form, submit and hit the save button.</p>
                    </div>
                      <div id=""  role="alert"></div>
                    <span id="" class="ml-3 text-danger"></span>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <img src="{{asset('assets/images/icons/minus.svg')}}">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" action="{{url('add-backlog-epic')}}" method="POST" >
                @csrf
                <input type="hidden" name="Stream_id" value="{{$organization->id}}">
      
                    <div class="row">
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="text" class="form-control" name="epic_name" id="" required>
                                <label for="objective-name">Epic Title</label>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-6">
                            <div class="form-group mb-0">
                                <input type="date" class="form-control"  name="epic_start_date" id=""  >
                                <label for="start-date">Start Date</label>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-6">
                            <div class="form-group mb-0">
                                <input type="date" class="form-control"  name="epic_end_date" id="" >
                                <label for="end-date">End Date</label>
                            </div>
                        </div>
                          <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                               <select class="form-control" name="epic_status">
                                    <option value="To Do">To Do</option>
                                  <option value="In progress">In Progress</option>
                                   <option value="Done">Done</option>

                               </select>
                                <label for="small-description">Status</label>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="text" class="form-control"  name="epic_description">
                                <label for="small-description">Small Description</label>
                            </div>
                        </div>
                        
                        <!--<h5 class="ml-3">Stories</h5>-->
                        
                        <!--  <div class="col-md-12 col-lg-12 col-xl-12">-->
                        <!--    <div class="form-group mb-0">-->
                        <!--        <input type="text" class="form-control epic-input" id="epic_story" required>-->
                        <!--        <label for="small-description">Add Story</label>-->
                        <!--    </div>-->
                        <!--</div>-->
                        
                        <div class="col-md-12 field_wrapper w-100"></div>
                        
                        
                        <!-- <div class="col-md-12">-->
                        <!--    <button class="btn btn-primary  w-50 mt-2 add_button" type="button">Add on item</button>-->
                        <!--</div>-->
                        
                        <div class="col-md-12">
                            <button class="btn btn-primary btn-lg btn-theme btn-block ripple mt-3"  type="submit">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="assign-backlog-epic" tabindex="-1" role="dialog" aria-labelledby="create-epic" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 526px !important;">
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="modal-title" id="create-epic">Assign Backlog Epic</h5>
                    </div>
                    <div class="col-md-12">
                        <p>Fill out the form, submit and hit the save button.</p>
                    </div>
                      <div id=""  role="alert"></div>
                    <span id="" class="ml-3 text-danger"></span>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <img src="{{asset('assets/images/icons/minus.svg')}}">
                </button>
            </div>
            <div class="modal-body">
            <form class="needs-validation" action="{{url('assign-backlog-epic')}}" method="POST">
            @csrf   
               
                <input type="hidden" name="backlog_id" id="values">

                    <div class="row">
                        <!--<div class="col-md-12 col-lg-12 col-xl-12">-->
                        <!--    <div class="form-group mb-0">-->
                        <!--        <input type="text" class="form-control" name="epic_name" id="" required>-->
                        <!--        <label for="objective-name">Epic Title</label>-->
                        <!--    </div>-->
                        <!--</div>-->
                    
                          <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                               <select class="form-control" id="category" name="stream_obj" required>
                                <option value="" >Select Value Stream</option>
                                <?php foreach(DB::table('value_stream')->where('org_id',$organization->org_id)->get() as $r){ ?>
                                  <option value="{{ $r->id }}">{{ $r->value_name }}</option>-->
                                   <?php }  ?>

                               </select>
                                <label for="small-description">Value Stream</label>
                            </div>
                        </div>
                        
                         <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                             <select name="locstate" id="obj" onchange="getvaluekey(this.value)"  class="form-control" value="" required>
                                                    
                            </select>
                                <label for="small-description">Objective</label>
                            </div>
                        </div>
                        
                              <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                             <select name="lockey" id="key" onchange="getvalueintit(this.value)"  class="form-control" value="" required>
                                                    
                            </select>
                                <label for="small-description">Key</label>
                            </div>
                        </div>
                        
                          <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                             <select name="locinit" id="init" class="form-control"  value="" required>
                                                    
                            </select>
                                <label for="small-description">Initiative</label>
                            </div>
                        </div>
                     
                        
                        <div class="col-md-12">
                            <button class="btn btn-primary btn-lg btn-theme btn-block ripple mt-3"  type="submit">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
      // DataTables initialization
    //   var table = $('#example').DataTable({
    //     "pagingType": "full_numbers",
    //     "language": {
    //       "paginate": {
    //         "previous": "&lsaquo;", // Custom previous arrow
    //         "next": "&rsaquo;" // Custom next arrow
    //       }
    //     }
    //   });

      // Check All checkbox functionality
      $('#checkAll').change(function() {
        $(':checkbox', 'tbody').prop('checked', this.checked);
      });
    });
    
    function get_epic()
    {
  
    var selectedOptions = [];
    $('.checkbox:checked').each(function() {
     selectedOptions.push($(this).val());
     
      });
      
      var selectedOptionsString = selectedOptions.join(',');

       $('#values').val(selectedOptionsString);
      
      if(selectedOptions.length > 0 )
      {
      $('#assign-backlog-epic').modal('show');
      $('#category').val('');
      }



   }
   
       $('#category').on('change', function() {
        var id = $(this).val();
   
        if(id) {
        $.ajax({
        type: "GET",
        url: "{{ url('get-value-obj') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        },
        success: function(res) {
          
        if(res)
        {
        $('#obj').empty();
        $('#obj').append('<option hidden>Choose Objective</option>'); 
        $.each(res, function(key, course){
        $('select[name="locstate"]').append('<option value="'+ course.id +'">' + course.objective_name+ '</option>');
        });
        }else{
        $('#obj').empty();
        
        }

        }
        });
      }else
      {
         $('#init').empty();
         $('#key').empty();
         $('#obj').empty();
      }

       });
        
       function getvaluekey(id)
        {
   
        $.ajax({
        type: "GET",
        url: "{{ url('get-value-key') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        },
        success: function(res) {
          
        if(res)
        {
        $('#key').empty();
        $('#key').append('<option hidden>Choose Key</option>'); 
        $.each(res, function(key, course){
        $('select[name="lockey"]').append('<option value="'+ course.id +'">' + course.key_name+ '</option>');
        });
        }else{
        $('#key').empty();
        }

        }
        });

        }
        
         function getvalueintit(id)
        {
   
        $.ajax({
        type: "GET",
        url: "{{ url('get-value-init') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        },
        success: function(res) {
          
        if(res)
        {
        $('#init').empty();
        $('#init').append('<option hidden value="">Choose Initiative</option>'); 
        $.each(res, function(key, course){
        $('select[name="locinit"]').append('<option value="'+ course.id +'">' + course.initiative_name+ '</option>');
        });
        }else{
        $('#init').empty();
        }

        }
        });

        }
        
        function assign_epic(val)
        {
            
        var slug = "{{$organization->slug}}";   
        var id = "{{$organization->id}}"; 
         
        $.ajax({
        type: "GET",
        url: "{{ url('get-assign-epic') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        slug:slug,
        val:val
        },
        success: function(res) {
          
        $('#assign-epic').html(res);
        

        }
        });

        }
        
        
      
        

  </script>


@endsection