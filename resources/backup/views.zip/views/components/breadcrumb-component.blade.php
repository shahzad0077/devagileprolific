<div class="subheader py-2 py-lg-2 px-lg-8 subheader-solid breadcrums" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
        <!--begin::Info-->
        <div class="d-flex align-items-start flex-column flex-wrap mr-2">
            <!--begin::Page Title-->
            <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">
                Objectives
            </h5>
            <div class="d-flex flex-row page-sub-titles">
                <div class="mr-2">
                    <p>Organizations</p>
                </div>
                <div class="mr-2">
                    <span>/</span>
                </div>
                <div class="mr-2">
                    <p>Departments</p>
                </div>
                <div class="mr-2">
                    <span>/</span>
                </div>
                <div class="mr-2">
                    <p>Objectives</p>
                </div>
            </div>
        </div>
        <!--end::Info-->
        <!--begin::Toolbar-->
        <div class="d-flex align-items-center toolbar">
            <div class="d-flex flex-row organization-drop align-items-center mr-3">
                <div class="img-cont mr-5">
                    <img src="{{asset('assets/images/icons/corporate-logo1.png')}}">
                </div>
                <div class="d-flex flex-column mr-3">
                    <div>
                        <p>Corporate Objectives</p>
                        <b>Hunddlers</b>
                    </div>
                </div>
                <div>
                    <img src="{{asset('assets/images/icons/dropdow-org.svg')}}">
                </div>
            </div>
            <div class="mr-3">
                <button class="btn-circle btn-tolbar bg-transparent">
                    <img src="{{asset('assets/images/icons/share.svg')}}" width="20" width="20">
                </button>
                <button class="btn-circle btn-tolbar bg-transparent">
                    <img src="{{asset('assets/images/icons/calendar.svg')}}" width="20" width="20">
                </button>
                <button class="btn-circle btn-tolbar bg-transparent">
                    <img src="{{asset('assets/images/icons/filter.svg')}}" width="20" width="20">
                </button>
            </div>
            <div class="mr-3">
                <div class="symbol-group symbol-hover">
                    <div class="symbol symbol-30 symbol-circle" data-toggle="tooltip" title="" data-original-title="Mark Stone">
                        <img alt="Pic" src="https://img.freepik.com/free-photo/handsome-confident-smiling-man-with-hands-crossed-chest_176420-18743.jpg?w=2000">
                    </div>
                    <div class="symbol symbol-30 symbol-circle" data-toggle="tooltip" title="" data-original-title="Charlie Stone">
                        <img alt="Pic" src="https://t4.ftcdn.net/jpg/02/98/28/89/360_F_298288984_8i0PB7s9aWPzi1LeuNGGrnjXkmXRpcZn.jpg">
                    </div>
                    <div class="symbol symbol-30 symbol-label-counter symbol-circle symbol-light" data-toggle="tooltip" title="" data-original-title="More users">
                        <span class="symbol-label font-weight-bold">5+</span>
                    </div>
                </div>
            </div>
            <div>
                <button class="button" data-toggle="modal" data-target="#create-objective">Add New</button>
            </div>
        </div>
        <!--end::Toolbar-->
    </div>
</div>