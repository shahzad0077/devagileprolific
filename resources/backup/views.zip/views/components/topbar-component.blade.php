<nav class="navbar navbar-expand-lg navbar-light bg-light main-topbar align-items-center">
    <a class="navbar-brand" href="#">
        <img src="{{asset('assets/images/icons/logo.svg')}}" width="109" height="37" class="d-inline-block align-top" alt="">
    </a>
    <div class="container-fluid d-flex align-items-stretch justify-content-between">
        <div>
        </div>
        <div>
            <div class="d-flex flex-row nav-action align-items-center">
                <div class="mr-2">
                    <button class="btn-circle btn-md bg-trans">
                        <img src="{{asset('assets/images/icons/message.svg')}}">
                        <span class="message-counter">3</span>
                    </button>
                </div>
                <div class="mr-2">
                    <span class="hr-separator"></span>
                </div>
                <div class="mr-2">
                    <button class="btn-circle btn-md bg-trans">
                        <img src="{{asset('assets/images/icons/settings.svg')}}">
                    </button>
                </div>
                <div class="mr-2">
                    <input type="text" class="form-control input-sm" placeholder="Search anything" name="">
                </div>
                <div class="mr-2">
                    
                        <button class="btn-circle btn-md text-primary bg-light-primary">
                        S
                       </button>

                        
                </div>
            </div>
        </div>
    </div>
</nav>