@php
$var_objective = "Org";
@endphp
@extends('components.main-layout')
@section('content')
<div class="row">
    <div class="col-md-12 py-3 p-0">
        <div class="card">
            <div class="card-body p-10">
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <button class="btn btn-sm btn-dark" onclick="delete_record();" type="button">Delete All</button>
                    </div>
                </div>
                <table class="table data-table">
                    <thead>
                      <tr>
                        <td>

                          <label class="form-checkbox">
                            <input type="checkbox" id="checkAll">
                            <span class="checkbox-label"></span>
                          </label>
                        </td>
                        <td>Organization</td>
                        <td>Email</td>
                        <td>Phone Number</td>
                        <td>Action</td>
                      </tr>
                    </thead>
                    <tbody>

                      @if (session('message'))
                      <div class="alert alert-success mt-1" role="alert">
                          {{ session('message') }}
                      </div>
                       @endif
                   
                      @if(count($organization) > 0)
                      @foreach($organization as $org)
                      @php
                      $objectivecount = DB::table('objectives')->where('org_id',$org->id)->where('trash',NULL)->count();
                      @endphp
                      <tr>
                        <td>
                          <label class="form-checkbox">
                            <input type="checkbox" class="checkbox" value="{{$org->id}}">
                            <span class="checkbox-label"></span>
                          </label>
                        </td>
                        <td class="image-cell">
                          @if($org->logo)    
                          <img src="{{asset('assets/images/'.$org->logo)}}" alt="Example Image">
                          @else
                          <img src="{{asset('assets/images/icons/logo.svg')}}" alt="Example Image">
                          @endif
                          <div>
                            <a href="{{url('objectives-contacts/'.$org->slug)}}" style="text-decoration: none;"><div class="title">{{$org->organization_name}}</div></a>
                            <div class="small-tag">{{$org->code}}</div>
                          </div>
                        </td>
                        <td>{{$org->email}}</td>
                        <td>{{$org->phone_no}}</td>
                        
                        <td>
                            <button class="btn-circle btn-tolbar" data-toggle="modal" data-target="#edit-org{{$org->id}}">
                                 <img src="{{asset('assets/images/icons/edit.svg')}}" data-toggle="tooltip" data-placement="top" data-original-title="Edit">
                             </button>
                             <button class="btn-circle btn-tolbar org-delete" data-id="{{$org->id}}" data-toggle="modal" data-target="#delete-org">
                                 <img src="{{asset('assets/images/icons/delete.svg')}}" data-toggle="tooltip" data-placement="top" data-original-title="Delete">
                             </button>
                        </td>
                      </tr>
                      @endforeach
                      @endif
                  
                      <!-- Add more rows as needed -->
                    </tbody>
                
                  </table> 
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
  // Select the form element

  function saveOrganization(){

    var file_data = $('#add_logo').prop('files')[0];
    var form_data = new FormData();
    form_data.append('add_logo', file_data);
    form_data.append('organization_name', $('#organization_name').val());
    form_data.append('phone', $('#phone').val());
    form_data.append('email', $('#email').val());
    form_data.append('_token', $('meta[name="csrf-token"]').attr('content'));
    form_data.append('small_description',$('#small_description').val());
    
      if (file_data) {
    form_data.append('add_logo', file_data);
        } else {
    form_data.append('add_logo', '');
        }


    if($('#organization_name').val()!='' || $('#phone').val()!='' || $('#email').val()!=''){
        $.ajax({
            type: "POST",
            url:"{{url('save-organization')}}", 
            data: form_data,
            cache: false,
            contentType: false,
            processData: false,
            success: function(res) {
              if(res == 1)
              {

              $('#email-error').html('<strong class="text-danger">Email Already Taken</strong>');

              }else if(res == 2)
              {
                $('#phone-error').html('<strong class="text-danger">Phone Number Already Taken</strong>');
                $('#email-error').html('');
              }else
              {
              $('#email-error').html(''); 
              $('#phone-error').html('');   
              $('#objective_name').val('');
              $('#email').val('');
              $('#phone').val('');
              $('#small_description').val('');
              $('#success').html('<div class="alert alert-success" role="alert"> Organization Created successfully</div>');
              $('#org-feild-error').html('');
              setTimeout(function() { 
                $('#create-org').modal('hide');

                location.reload();
            }, 3000);
              }
            
            }
        });
    }else{
           
        $('#org-feild-error').html('Please fill out all required fields.');

    }
}

$('.org-delete').click(function(){

  var org_id = $(this).attr('data-id');

  $('#org-id').val(org_id);

});

// function UpdateOrganization(){
//     var file_data = $('#logo').prop('files')[0];
//     var form_data = new FormData();
//     if (file_data) {
//         form_data.append('logo', file_data);
//         } else {
//     var oldImageFilePath = $('#old_image').val();
//     form_data.append('old_image', oldImageFilePath);
//         }

//     form_data.append('objective_name', $('#objective_name').val());
//     form_data.append('phone', $('#phone').val());
//     form_data.append('email', $('#email').val());
//     form_data.append('_token', $('meta[name="csrf-token"]').attr('content'));
//     form_data.append('small_description',$('#small_description').val());
//     form_data.append('org_edit_id', $('#org_edit_id').val());



//     if($('#objective_name').val()!='' || file_data!=undefined || $('#phone').val()!='' || $('#email').val()!=''){
//         $.ajax({
//             type: "POST",
//             url:"{{url('update-organization')}}", 
//             data: form_data,
//             cache: false,
//             contentType: false,
//             processData: false,
//             success: function(res) {
           
//               $('#edit_message').html('<div class="alert alert-success" role="alert"> Organization Updated successfully</div>');
         

//               setTimeout(function() { 
//                 $('#edit-org').modal('hide');
//                 location.reload();
//             }, 2000);
              
            
//             }
//         });
//     }
// }

$("#checkAll").click(function () {
$('input:checkbox').not(this).prop('checked', this.checked);
			});
			
function delete_record()
{
  
     var selectedOptions = [];
    $('.checkbox:checked').each(function() {
     selectedOptions.push($(this).val());
     
});

  $.ajax({
            type: "POST",
            url:"{{url('delete-mutiple-organization')}}", 
             data:{selectedOptions:selectedOptions,_token:'{{ csrf_token() }}'},
            success: function(res) {
                
             location.reload();
            }
        });
}
			
</script>

<div class="modal fade" id="edit-org{{$org->id}}" tabindex="-1" role="dialog" aria-labelledby="edit-org" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 526px !important;">
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="modal-title" id="create-epic">Update Organization</h5>
                    </div>
                    <div class="col-md-12">
                        <p>Fill out the form, submit and hit the save button.</p>
                    </div>
                    <div id="edit_message" ></div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <img src="{{asset('assets/images/icons/minus.svg')}}">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation"  enctype="multipart/form-data" method="POST" action="{{url('update-organization')}}" id="">
                    @csrf
                    <input type="hidden" value="{{$org->id}}" id="org_edit_id" name="org_edit_id">
                    <div class="row">
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="text" class="form-control" value="{{$org->organization_name}}" name="organization_name" required id="objective_name" required>
                                <label for="objective-name">organization Name</label>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="text" class="form-control" value="{{$org->email}}" required name="email" id="" required>
                                <label for="start-date">Email</label>
                            </div>
                        </div>

                        <small id="" class="mb-2 ml-5"></small>

                          
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="number" class="form-control" value="{{$org->phone_no}}" required name="phone_no" id="" required>
                                <label for="end-date">Phone number</label>
                            </div>
                        </div>
                        <small id="" class="mb-2 ml-5"></small>
                        <input type="hidden" id="old_image" name="old_image" value="{{ $org->logo }}">
                        <div class="col-md-12 col-lg-12 col-xl-12">
                          <img src="{{asset('assets/images/'.$org->logo)}}" style="width:200px; height:130px; object-fit:cover" alt="Example Image">
                             <div class="form-group mb-0">
                                <input type="file" class="form-control" value="" name="logo" id="">
                                <label for="logo">Logo
                                </label>

                            </div>

                        </div>

                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="text" class="form-control" value="{{$org->detail}}" name="detail" id="small_description" required>
                                <label for="small-description">Small Description</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button  type="submit" class="btn btn-primary btn-lg btn-theme btn-block ripple">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection