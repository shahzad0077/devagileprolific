@php
$var_objective = $type;
@endphp
@extends('components.main-layout')
<style>
    .show-read-more .more-text{
        display: none;
    }
</style>
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div id="parentCollapsible">
                        <!-- Parent Collapsible -->
                        @if(count($objective) > 0)
                        @foreach($objective as $obj)

                        @php
                        $keyResultcount  = DB::table('key_result')->where('obj_id',$obj->id)->count();
                        $keyweightcounte = DB::table('key_result')->where('obj_id',$obj->id)->sum('weight');
                        @endphp
                        <div class="card bg-transparent shadow-none">
                            <div class="card-header objective-header active-header bg-white border-bottom" id="parentHeading">
                                <div class="d-flex flex-row justify-content-between header-objective align-items-center"
                                    data-toggle="collapse" data-target="#nestedCollapsible{{$obj->id}}">
                                    <div class="title">
                                        <h5>
                                            <div class="d-flex flex-row align-items-center">
                                                <div>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                                      <rect width="32" height="32" rx="16" fill="#3699FF"/>
                                                      <path d="M25 16H21.4M10.6 16H7M16 10.6V7M16 25V21.4M23.2 16C23.2 19.9765 19.9765 23.2 16 23.2C12.0235 23.2 8.8 19.9765 8.8 16C8.8 12.0235 12.0235 8.8 16 8.8C19.9765 8.8 23.2 12.0235 23.2 16ZM18.7 16C18.7 17.4912 17.4912 18.7 16 18.7C14.5088 18.7 13.3 17.4912 13.3 16C13.3 14.5088 14.5088 13.3 16 13.3C17.4912 13.3 18.7 14.5088 18.7 16Z" stroke="white" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                </div>
                                                <div class="ml-2">
                                                    {{$obj->objective_name}}
                                                </div>
                                            </div>
                                        </h5>
                                    </div>
                                    <div class="d-flex flex-row justify-content-between content align-items-center">
                                        <div>
                                            <p>{{$keyResultcount}} Key Results</p>
                                        </div>
                                        <div>
                                            <p>{{ \Carbon\Carbon::parse($obj->start_date)->format('M d')}} - {{ \Carbon\Carbon::parse($obj->end_date)->format('M d')}}</p>
                                        </div>
                                        <div>
                                            @if($obj->status == 'In progress')
                                            <span class="badge-cs warning w-100">In progress</span>
                                            @endif
                                            @if($obj->status == 'Done')
                                            <span class="badge-cs success">Done</span>
                                            @endif
                                            @if($obj->status == 'To Do')
                                            <span class="badge-cs bg-primary">To Do</span>
                                            @endif

                                        </div>
                                        
                                           <div>
                                            <div class="d-flex flex-row progress-section">
                                               
                                                <div class="d-flex justify-content-between">
                                                    <span class="tasks"></span>
                                                    <span class="completion" id="obj_comp_q{{$obj->id}}">{{$obj->q_obj_prog}}% Completed</span>
                                                </div>
                                            </div>
                                         
                                             
                                        </div>
                                        
                                        <div>
                                            <div class="d-flex flex-row progress-section">
                                               
                                                <div class="d-flex justify-content-between">
                                                    <span class="tasks"></span>
                                                    <span class="completion" id="obj_comp{{$obj->id}}">{{round($obj->obj_prog,2)}}% Completed</span>
                                                </div>
                                            </div>
                                         
                                             <div class="progress">
                                            <div class="progress-bar bg-primay" id="obj_prog{{$obj->id}}"  role="progressbar" style="width:{{$obj->obj_prog}}%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                         
                                    </div>
                                      @if($keyweightcounte > 0)
                                            @if($keyweightcounte > 100)
                                            <div class=" text-danger w-25" role="">
                                              <small>Adjust Key Weight to 100 ({{$keyweightcounte}})</small>
                                            </div>
                                            @endif
                                             @if($keyweightcounte < 100)
                                            <div class=" text-danger" role="">
                                             <small>Adjust Key Weight to 100  ({{$keyweightcounte}})</small>
                                            </div>
                                            @endif
                                            @endif
                                            
                                             @php
                                            $objedit = preg_replace('/[^\p{L}\p{N}\s]/u', '',$obj->detail);
                                            $trimmedStringobj = trim($objedit);
                                            @endphp
                                    <div class="action ml-0">
                                        <button class="btn btn-icon btn-circle btn-tolbar ml-auto" onclick="editobjective({{$obj->id}},'{{$obj->objective_name}}','{{$obj->start_date}}','{{$obj->end_date}}','{{$trimmedStringobj}}','{{$obj->status}}')" data-toggle="modal" data-target="#edit-objective">
                                            <img src="{{ asset('assets/images/icons/edit.svg') }}" alt="Edit"
                                                style="border-radius: 50%; width: 18px; height: 18px;">
                                        </button>
                                        <button class="btn btn-icon btn-circle btn-tolbar delete-obj" onclick="deleteobj({{$obj->id}})" data-toggle="modal" data-target="#delete-objective">
                                            <img src="{{ asset('assets/images/icons/delete.svg') }}" alt="Delete"
                                                style="border-radius: 50%; width: 18px; height: 18px;">
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="nestedCollapsible{{$obj->id}}" class="collapse">
                                <div class="card-body p-0">
                                    <!-- begin Key Results -->
                                    <div>
                                        <!-- begin Item -->
                                        @php
                                        $keyResult  = DB::table('key_result')->where('obj_id',$obj->id)->get();
                                        @endphp

                                        <div class="row">
                                            <div class="col-md-12">
                                                @if(count($keyResult) > 0)
                                                @foreach($keyResult as $key)

                                                
                                                    @php
                                                    $initiativeResultCount  = DB::table('initiative')->where('key_id',$key->id)->count();
                                                    $initiativeweightcount = DB::table('initiative')->where('key_id',$key->id)->sum('initiative_weight');
                                                    @endphp
                                                <div class="card bg-transparent shadow-none">
                                                    <div class="card-header keyresult-header bg-light-gray">
                                                        <div class="d-flex flex-row justify-content-between header-objective align-items-center"
                                                            data-toggle="collapse" data-target="#key-result{{$key->id}}">
                                                            <div class="title">
                                                                <h5>
                                                                    <div class="d-flex flex-row align-items-center">
                                                                        <div>
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                                                              <rect width="32" height="32" rx="16" fill="#3699FF"/>
                                                                              <path d="M19.5 13.5C19.5 13.1161 19.3535 12.7322 19.0607 12.4393C18.7678 12.1464 18.3839 12 18 12M18 18C20.4853 18 22.5 15.9853 22.5 13.5C22.5 11.0147 20.4853 9 18 9C15.5147 9 13.5 11.0147 13.5 13.5C13.5 13.7053 13.5137 13.9073 13.5404 14.1053C13.5841 14.4309 13.606 14.5937 13.5913 14.6967C13.5759 14.804 13.5564 14.8618 13.5035 14.9564C13.4527 15.0473 13.3633 15.1367 13.1843 15.3157L9.35147 19.1485C9.22176 19.2782 9.1569 19.3431 9.11052 19.4188C9.0694 19.4859 9.0391 19.559 9.02072 19.6356C9 19.7219 9 19.8136 9 19.9971V21.3C9 21.72 9 21.9301 9.08175 22.0905C9.15365 22.2316 9.26839 22.3463 9.40951 22.4183C9.56994 22.5 9.77996 22.5 10.2 22.5H12V21H13.5V19.5H15L16.1843 18.3157C16.3633 18.1367 16.4527 18.0473 16.5436 17.9965C16.6382 17.9436 16.696 17.9241 16.8033 17.9087C16.9063 17.894 17.0691 17.9159 17.3947 17.9596C17.5927 17.9863 17.7947 18 18 18Z" stroke="white" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                            </svg>
                                                                        </div>
                                                                        <div class="ml-2">
                                                                            {{$key->key_name}}
                                                                        </div>
                                                                    </div>
                                                                </h5>
                                                            </div>
                                                            <div
                                                                class="d-flex flex-row justify-content-between content align-items-center">
                                                                <div class="text-center">
                                                                    <p>{{$initiativeResultCount}} Initiatives</p>
                                                                </div>
                                                                <div class="text-center">
                                                                    <p>{{ \Carbon\Carbon::parse($key->key_start_date)->format('M d')}} - {{ \Carbon\Carbon::parse($key->key_end_date)->format('M d')}}</p>
                                                                </div>
                                                                <div class="text-center">
                                                                    <!--@if($key->key_status == 1)-->
                                                                    <!--<span class="badge-cs success">Running</span>-->
                                                                    <!--@else-->
                                                                    <!--<span class="badge-cs warning">Paused</span>-->
                                                                    <!--@endif-->
                                                                    
                                                                      @if($key->key_status == 'In progress')
                                                                        <span class="badge-cs warning w-100">In progress</span>
                                                                        @endif
                                                                        @if($key->key_status == 'Done')
                                                                        <span class="badge-cs success">Done</span>
                                                                        @endif
                                                                        @if($key->key_status == 'To Do')
                                                                        <span class="badge-cs bg-primary">To Do</span>
                                                                        @endif
                        
                                                                </div>
                                                                
                                                            <div>
                                                                    <div class="d-flex flex-row progress-section">
                                                                        
                                                                        <div class="d-flex justify-content-between">
                                                                            <span class="tasks"></span>
                                                                            <span class="completion" id="qkeycomp{{$key->id}}">{{$key->q_key_prog}}% Completed</span>
                                                                        </div>
                                                                    </div>
                                                                   
                                                        </div>
                                                                
                                                                <div>
                                                                    <div class="d-flex flex-row progress-section">
                                                                        
                                                                        <div class="d-flex justify-content-between">
                                                                            <span class="tasks"></span>
                                                                            <span class="completion" id="keycomp{{$key->id}}">{{round($key->key_prog,2)}}% Completed</span>
                                                                        </div>
                                                                    </div>
                                                         <div class="progress">
                                                         <div class="progress-bar bg-primay" id="keyprog{{$key->id}}" role="progressbar" style="width:{{$key->key_prog}}%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                                          </div>            
                                                        </div>
                                                        
                                                            </div>
                                                            
                                                              @if($initiativeweightcount > 0)
                                                                @if($initiativeweightcount > 100)
                                                                <div class=" text-danger w-25" role="">
                                                                  <small>Adjust Key Weight to 100 ({{$initiativeweightcount}})</small>
                                                                </div>
                                                                @endif
                                                                 @if($initiativeweightcount < 100)
                                                                <div class=" text-danger" role="">
                                                                 <small>Adjust Key Weight to 100  ({{$initiativeweightcount}})</small>
                                                                </div>
                                                                @endif
                                                                @endif
                                                                
                                                                @php
                                                                $keyedit = preg_replace('/[^\p{L}\p{N}\s]/u', '',$key->key_detail);
                                                                $trimmedStringkey = trim($keyedit);
                                                                @endphp
                                                            <div class="action ml-0">
                                                                <button
                                                                    class="btn btn-icon btn-circle bg-white btn-tolbar ml-auto" onclick="editobjectivekey({{$key->id}},'{{$key->key_name}}','{{$key->key_start_date}}','{{$key->key_end_date}}','{{$trimmedStringkey}}','{{$key->weight}}','{{$obj->id}}')" data-toggle="modal" data-target="#edit-key-result">
                                                                    <img src="{{ asset('assets/images/icons/edit.svg') }}"
                                                                        alt="Edit"
                                                                        style="border-radius: 50%; width: 18px; height: 18px;">
                                                                </button>
                                                                <button class="btn btn-icon btn-circle bg-white btn-tolbar" onclick="deleteobjkey({{$key->id}},'{{$obj->id}}')" data-toggle="modal" data-target="#delete-objective-key">
                                                                    <img src="{{ asset('assets/images/icons/delete.svg') }}"
                                                                        alt="Delete"
                                                                        style="border-radius: 50%; width: 18px; height: 18px;">
                                                                </button>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>

                                                    @php
                                                    $initiativeResult  = DB::table('initiative')->where('key_id',$key->id)->get();
                                                    @endphp

                                                    <div id="key-result{{$key->id}}" class="collapse">
                                                        <div class="card-body p-0">
                                                            <!-- begin Initiative -->
                                                            <div>
                                                                <!-- begin Item -->
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        @if(count($initiativeResult) > 0)
                                                                        @foreach($initiativeResult as $initiative)
                                                                        
                                                                        @php
                                                                        $InitiativeProgress = 0;
                                                                        $EpicCount;
                                                                        $EpicCount = DB::table('epics')->where('initiative_id',$initiative->id)->count();
                                                                        $monthIds = DB::table('epics')->where('initiative_id',$initiative->id)->pluck('id');

                                                                            $epicData = [];
                                                                            foreach ($monthIds as $monthId) {
                                                                                $epicData[] = $monthId;
                                                                            }
                                                                           $EpicStory  = DB::table('epics_stroy')->whereIn('epic_id',$epicData)->sum('progress');
                                                                           if($EpicCount > 0)
                                                                           {
                                                                           $InitiativeProgress = round($EpicStory/$EpicCount,2);
                                                                           }else
                                                                           {
                                                                           $InitiativeProgress = 0;
                                                                           }
                                                                     
                                                                           @endphp
                        
                                                                        <div class="card bg-transparent shadow-none">
                                                                            <div class="card-header initiative-header"
                                                                                style="background: #f9   f9f9 !important;">
                                                                                <div class="d-flex flex-row justify-content-between header-objective align-items-center"
                                                                                    data-toggle="collapse"
                                                                                    data-target="#initiative{{$initiative->id}}" onclick="handleDivClick({{$initiative->id}})">
                                                                                    <div class="title" >
                                                                                        <h5>
                                                                                            <div class="d-flex flex-row align-items-center">
                                                                                                <div>
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                                                                                      <rect width="32" height="32" rx="16" fill="#3699FF"/>
                                                                                                      <path d="M18.4 19.6V21.6C18.4 22.3455 18.4 22.7183 18.2782 23.0123C18.1158 23.4043 17.8043 23.7158 17.4123 23.8782C17.1183 24 16.7455 24 16 24C15.2545 24 14.8817 24 14.5877 23.8782C14.1957 23.7158 13.8842 23.4043 13.7218 23.0123C13.6 22.7183 13.6 22.3455 13.6 21.6V19.6M18.4 19.6C20.5191 18.6741 22 16.4604 22 14C22 10.6863 19.3137 8 16 8C12.6863 8 10 10.6863 10 14C10 16.4604 11.4809 18.6741 13.6 19.6M18.4 19.6H13.6" stroke="white" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                                                    </svg>
                                                                                                </div>
                                                                                                <div class="ml-2">
                                                                                                    {{$initiative->initiative_name}}
                                                                                                </div>
                                                                                            </div>
                                                                                        </h5>
                                                                                    </div>
                                                                                    <div
                                                                                        class="d-flex flex-row justify-content-between content align-items-center" >
                                                                                        <div class="text-center">
                                                                                            <p >{{$EpicCount}} Epics</p>
                                                                                        </div>
                                                                                        <div class="text-center">
                                                                                            <p>{{ \Carbon\Carbon::parse($initiative->initiative_start_date)->format('M d')}} - {{ \Carbon\Carbon::parse($initiative->initiative_end_date)->format('M d')}}</p>
                                                                                        </div>
                                                                                        <div class="text-center">
                                                                                            <!--@if($initiative->initiative_status == 1)-->
                                                                                            <!--<span-->
                                                                                            <!--    class="badge-cs warning">Paused</span>-->
                                                                                            <!--@else-->
                                                                                            <!--<span-->
                                                                                            <!--class="badge-cs success">Paused</span>-->
                                                                                            <!--@endif-->
                                                                                            
                                                                                              @if($initiative->initiative_status == 'In progress')
                                                                                                <span class="badge-cs warning w-100">In progress</span>
                                                                                                @endif
                                                                                                @if($initiative->initiative_status == 'Done')
                                                                                                <span class="badge-cs success">Done</span>
                                                                                                @endif
                                                                                                @if($initiative->initiative_status == 'To Do')
                                                                                                <span class="badge-cs bg-primary">To Do</span>
                                                                                                @endif
                                                                                        </div>
                                                                                        
                                                                                                 <div>

                                                                                            <div
                                                                                                class="d-flex flex-row progress-section">
                                                                                                <div
                                                                                                    class="d-flex justify-content-between">
                                                                                                    <span
                                                                                                        class="tasks"></span>
                                                                                                    <span class="completion"  id="qcomp{{$initiative->id}}" > {{$initiative->q_initiative_prog}}% Completed</span>
                                                                                                </div>
                                                                                            </div>
                                                                                 
                                                                                        </div>
                                                                                        
                                                                                        
                                                                                        <div>

                                                                                            <div
                                                                                                class="d-flex flex-row progress-section">
                                                                                               
                                                                                                
                                                                                                            
                                                                                                            
                                                                                                <div
                                                                                                    class="d-flex justify-content-between">
                                                                                                    <span
                                                                                                        class="tasks"></span>
                                                                                                    <span class="completion" id="comp{{$initiative->id}}" > {{round($initiative->initiative_prog,2)}}% Completed</span>
                                                                                                </div>
                                                                                            </div>
                                                                                    <div class="progress">
                                                                                    <div class="progress-bar bg-primay" id="proginit{{$initiative->id}}" role="progressbar" style="width: {{$initiative->initiative_prog}}%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                                                                        </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    
                                                                                    @php
                                                                                    $initedit = preg_replace('/[^\p{L}\p{N}\s]/u', '',$initiative->initiative_detail);
                                                                                    $trimmedStringinit = trim($initedit);
                                                                                    @endphp
                                                    
                                                                                    <div class="action ml-0">
                                                                                        <button
                                                                                            class="btn btn-icon btn-circle bg-white btn-tolbar ml-auto" onclick="editinitiative({{$initiative->id}},'{{$initiative->initiative_name}}','{{$initiative->initiative_start_date}}','{{$initiative->initiative_end_date}}','{{$trimmedStringinit}}','{{$initiative->initiative_weight}}','{{$key->id}}','{{$obj->id}}')" data-toggle="modal" data-target="#edit-initiative">
                                                                                            <img src="{{ asset('assets/images/icons/edit.svg') }}"
                                                                                                alt="Edit"
                                                                                                style="border-radius: 50%; width: 18px; height: 18px;">
                                                                                        </button>
                                                                                        <button
                                                                                            class="btn btn-icon btn-circle bg-white btn-tolbar" onclick="deletekeyinitiative({{$initiative->id}},'{{$key->id}}','{{$obj->id}}')" data-toggle="modal" data-target="#delete-initiative-key">
                                                                                            <img src="{{ asset('assets/images/icons/delete.svg') }}"
                                                                                                alt="Delete"
                                                                                                style="border-radius: 50%; width: 18px; height: 18px;">
                                                                                        </button>
                                                                                    <button
                                                                                            class="btn  btn-primary border-1" data-toggle="modal" onclick="addepic({{$initiative->id}},'{{$key->id}}','{{$obj->id}}')" data-target="#create-epic">
                                                                                             epics
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            @php
                                                                            $quarter  = DB::table('quarter')->where('initiative_id',$initiative->id)->get();
                                                                            @endphp
                                                                            <div id="initiative{{$initiative->id}}" class="collapse" >
                                                                                     
                                                                            <div class="container-fluid py-7" style="width: 96%; margin: 0px auto;">
                                                                                <div class="row">
                                                                                <div class="col-md-12">
                                                                                <div class="card">
                                                                                <div class="card-body">
                                                                                    <div class="board-kanban">
                                                                                        <div class="container-scroll" id="container-scroll-{{$initiative->id}}">
                                                                                        @if(count($quarter) > 0)    
                                                                                        @foreach($quarter as $q)
                                                                                        @php
                                                                                           $quarterMonth  = DB::table('quarter_month')->where('quarter_id',$q->id)->get();
                                                                                           $quarterMonthCount  = DB::table('quarter_month')->where('quarter_id',$q->id)->count();
                                                                                          @endphp
                                                                                           @if($quarterMonthCount > 0) 
                                                                                                <div id="section-{{$initiative->id}}" class="section-scroll">
                                                                                                <div
                                                                                                    class="card bg-transparent shadow-none">
                                                                                                    <div class="row">
                                                                                                        <div
                                                                                                            class="col-md-12">
                                                                                                            <div
                                                                                                                class="card-header bg-white align-items-center">
                                                                                                                <div
                                                                                                                    class="d-flex justify-content-between">
                                                                                                                    <div>
                                                                                                                        <button
                                                                                                                             onclick="shiftLeft({{$initiative->id}})"
                                                                                                                            class="btn-circle btn-tolbar"><img
                                                                                                                                src="{{asset('assets/images/icons/angle-left.svg')}}"></button>
                                                                                                                    </div>
                                                                                                                    <div>
                                                                                                                        <h3
                                                                                                                            class="title" >
                                                                                                                            {{$q->quarter_name}}  {{$q->year}}
                                                                                                        
                                                                                                                        </h3>
                                                                                                                    </div>
                                                                                                                    <div>
                                                                                                                        <button
                                                                                                                            onclick="shiftRight({{$initiative->id}})"
                                                                                                                            class="btn-circle btn-tolbar"><img
                                                                                                                                src="{{asset('assets/images/icons/angle-right.svg')}}"></button>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div
                                                                                                        class="card-body p-0">
                                                                                                        <div class="board-body"
                                                                                                            style="height:80vh">
                                                                                                            <div
                                                                                                                class="board-cards p-5">
                                                                                                                <div
                                                                                                                    id="scroller">
                                                                                                                   @if(count($quarterMonth) > 0)    
                                                                                                                   @foreach($quarterMonth as $month)
                                                                                                                    @php
                                                                                                                    $epic  = DB::table('epics')->where('month_id',$month->id)->get();
                                                                                                                    @endphp
                                                                                                                    <div class="board"
                                                                                                                        id="{{$month->id}}">
                                                                                                                        <header
                                                                                                                            class="noselect">
                                                                                                                            {{$month->month}}
                                                                                                                        </header>
                                                                                                                        @if(count($epic) > 0)
                                                                                                                        @foreach($epic as $e)
                                                                                                                        
                                            
                                                                                                                        <div class="cards target"
                                                                                                                           id="{{$e->id}}"
                                                                                                                            draggable="true" >
                                                                                                                            <div
                                                                                                                                class="card">
                                                                                                                                <div
                                                                                                                                    class="card card-epic border-radius" style="margin-bottom:0px !important">
                                                                                                                                    <div
                                                                                                                                        class="card-header bg-white border-radius">
                                                                                                                                        <div
                                                                                                                                            class="d-flex flex-row justify-content-between">
                                                                                                                                            <div>
                                                                                                                                                @if($e->epic_status == 'Done')
                                                                                                                                                <span
                                                                                                                                                    class="badge-cs success">{{$e->epic_status}}</span>
                                                                                                                                                @endif
                                                                                                                                                 @if($e->epic_status == 'In progress')
                                                                                                                                                <span
                                                                                                                                                    class="badge-cs warning w-100">{{$e->epic_status}}</span>
                                                                                                                                                @endif 
                                                                                                                                                 @if($e->epic_status == 'To Do')
                                                                                                                                                <span
                                                                                                                                                    class="badge-cs bg-primary ">{{$e->epic_status}}</span>
                                                                                                                                                @endif 
                                                                                                                                                
                                                                                                                                            </div>
                                                                                                                                            <div>
                                                                                                                                                <div
                                                                                                                                                    class="dropdown">
                                                                                                                                                    <button
                                                                                                                                                        class="btn-circle btn-tolbar dropdown-toggle bg-white"
                                                                                                                                                        type="button"
                                                                                                                                                        id="dropdownMenuButton"
                                                                                                                                                        data-toggle="dropdown"
                                                                                                                                                        aria-haspopup="true"
                                                                                                                                                        aria-expanded="false" >
                                                                                                                                                        <img
                                                                                                                                                            src="{{ asset('assets/images/icons/dots.svg') }}">
                                                                                                                                                    </button>
                                                                                                                                                    @php
                                                                                                                                                    $test = preg_replace('/[^\p{L}\p{N}\s]/u', '', $e->epic_detail);
                                                                                                                                                    $trimmedString = trim($test);
                                                                                                                                                    @endphp
                                                                                                                                                    <div class="dropdown-menu"
                                                                                                                                                        aria-labelledby="dropdownMenuButton">
                                                                                                                                                        <a class="dropdown-item"
                                                                                                                                                            href="#" data-toggle="modal" onclick="editepic({{$e->id}},'{{$e->epic_name}}','{{$e->epic_start_date}}','{{$e->epic_end_date}}','{{$trimmedString}}','{{$e->epic_status}}','{{$initiative->id}}','{{$key->id}}','{{$obj->id}}')" data-target="#edit-epic">Edit</a>
                                                                                                                                                        <a class="dropdown-item"
                                                                                                                                                            href="#" onclick="DeleteEpic({{$e->id}},'{{$initiative->id}}','{{$key->id}}','{{$obj->id}}')">Delete</a>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    @php
                                                                                                                                    $str = strlen($e->epic_name);
                                                                                                                                    @endphp
                                                                                                                                    <div
                                                                                                                                        class="card-body" >
                                                                                                                                        <h6
                                                                                                                                            class="title load-more">
                                                                                                                                            {{ \Illuminate\Support\Str::limit($e->epic_name,20, $end='...') }}
                                                                                                                                            @if($str > 20)
                                                                                                                                            <a href="javascript:void(0);" onclick="loadmore({{$e->id}});" id="toggle-button{{$e->id}}" class="" style="font-size:12px;">Read More...</a>
                                                                                                                                            @endif
                                                                                                                                        </h6>
                                                                                                                                        
                                                                                                                                         <h6
                                                                                                                                            class="title more-content" style="line-height:15px !important;display:none">
                                                                                                                                            {{$e->epic_name}}
                                                                                                                                            
                                                                                                                                        </h6>
                                                                                                                                        <p
                                                                                                                                            class="content show-read-more">
                                                                                                                                            {{$e->epic_detail}}
                                                                                                                                        </p>
                                                                                                                                        <div
                                                                                                                                            class="progress">
                                                                                                                                            <div class="progress-bar bg-primay" 
                                                                                                                                                role="progressbar"
                                                                                                                                                style="width: {{$e->epic_progress}}%;"
                                                                                                                                                aria-valuenow="70"
                                                                                                                                                aria-valuemin="0"
                                                                                                                                                aria-valuemax="100" id="progepic{{$e->id}}">
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div
                                                                                                                                        class="card-footer bg-white border-none">
                                                                                                                                        <div
                                                                                                                                            class="d-flex flex-row justify-content-between">
                                                                                                                                            <div>
                                                                                                                                                <span>{{ \Carbon\Carbon::parse($e->epic_start_date)->format('M d')}}</span>
                                                                                                                                            </div>
                                                                                                                                            <div>
                                                                                                                                                <span>{{ \Carbon\Carbon::parse($e->epic_end_date)->format('M d')}}</span>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        
                                                                                                                      
                                                                                                                        @endforeach
                                                                                                                        @endif
                                                                                                                      
                                                                                                                      <button
                                                                                                                            class="btn  btn-primary border-1 ml-3 no-drag" onclick="addepicmonth({{$month->id}},'{{$month->month}}','{{$q->id}}','{{$initiative->id}}','{{$key->id}}','{{$obj->id}}')" data-toggle="modal" data-target="#create-epic-month" draggable="false">
                                                                                                                             Add Epics
                                                                                                                        </button>
                                                                                                                        
                                                                                                                    </div>
                                                                                                                      
                                                                                                                  
                                                                                                                    @endforeach
                                                                                                                    @endif
                                                                                                           
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div
                                                                                                                class="d-flex flex-row-reverse zoom-btn-section">
                                                                                                                <div>
                                                                                                                    <button
                                                                                                                        class="btn-circle btn-zoom-buttons zoom">
                                                                                                                        <img width="20px"
                                                                                                                            height="20px"
                                                                                                                            src="{{asset('assets/images/icons/search-zoom-in.svg')}}"
                                                                                                                            alt="zoom-In">
                                                                                                                    </button>
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="mr-2">
                                                                                                                    <button
                                                                                                                        class="btn-circle btn-zoom-buttons zoom-out">
                                                                                                                        <img width="20px"
                                                                                                                            height="20px"
                                                                                                                            src="{{asset('assets/images/icons/search-zoom-out.svg')}}"
                                                                                                                            alt="zoom-Out">
                                                                                                                    </button>
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="mr-2">
                                                                                                                    <button
                                                                                                                        class="btn-circle btn-zoom-buttons zoom-init">
                                                                                                                        <img width="20px"
                                                                                                                            height="20px"
                                                                                                                            src="{{asset('assets/images/icons/maximize.svg')}}"
                                                                                                                            alt="zoom-Out">
                                                                                                                    </button>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>

                                                                                                </div>
                                                                                            </div>
                                                                                            @endif
                                                                                            @endforeach
                                                                                            @endif

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                                      @php
                                                                      $initiativeweightcounte = DB::table('initiative')->where('key_id',$key->id)->sum('initiative_weight');
                                                                      @endphp
                                                                <!-- end Item -->
                                                                <!-- begin Add New -->
                                                                <div class="row py-2">
                                                                    <div class="col-md-12">
                                                                        <a href="" data-toggle="modal" onclick="initiative({{$key->id}},'{{$obj->id}}','{{$initiativeweightcounte}}')"
                                                                            data-target="#create-initiative"
                                                                            class="col-action"><img
                                                                                src="{{ asset('assets/images/icons/add-circle.svg') }}"
                                                                                class="mr-1"> Add Initiative</a>
                                                                    </div>
                                                                </div>
                                                                <!-- end Add New -->
                                                            </div>
                                                            <!-- end Initiative -->
                                                        </div>
                                                    </div>
                                                </div>
                                                @endforeach
                                                @endif
                                            </div>
                                        </div>
                                        <!-- end Item -->
                                        <!-- begin Add New -->
                                        @php
                                        $keyweightcount = DB::table('key_result')->where('obj_id',$obj->id)->sum('weight');
                                        @endphp
                                        
                                        <div class="row py-2">
                                            <div class="col-md-12">
                                                <a href="" onclick="objective({{$obj->id}},'{{$keyweightcount}}')" data-toggle="modal" data-target="#create-key-result"
                                                    class="col-action key_obj"><img
                                                        src="{{ asset('assets/images/icons/add-circle.svg') }}"
                                                        class="mr-1"> Add Key Result</a>
                                            </div>
                                        </div>
                                        <!-- end Add New -->
                                    </div>
                                    <!-- end Key Results -->
                                </div>
                            </div>
                        </div>
                        @endforeach
                        @else
                        No objective found.
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
 
@endsection