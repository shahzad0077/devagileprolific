@php
$var_objective = "Org-Unit-team";
@endphp
@extends('components.main-layout')
<title>Organization Business Units</title>
@section('content')


    <div class="d-flex flex-column flex-root">
        <!-- begin topbar -->
        
        <!--begin::Page-->
        <div class="page d-flex flex-row flex-column-fluid">
            <!-- begin Sidebar -->
        
  
            <!-- end Sidebar -->
            <div class="content d-flex flex-column flex-column-fluid">
                <!-- begin breadcrums -->
             
                <!-- end breadcrums -->
                <!-- begin page Content -->
                <div class="container py-3">
                    <div class="row">
                   
                        <div class="col-md-12 p-0">
                            <div class="card">
                                <div class="card-body p-10">
                                    <table class="table data-table">
                                                <thead>
                                                    <tr>
                                                        <td>
                                                            <label class="form-checkbox">
                                                                <input type="checkbox" id="checkAll">
                                                                <span class="checkbox-label"></span>
                                                            </label>
                                                        </td>
                                                        <td>Team Name</td>
                                                        <td>Members</td>
                                                        <td>Value Streams</td>
                                                        <td>Team Leader</td>
                                                        <td>Action</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                   @if(count($Team) > 0)
                                                   @foreach($Team as $team)
                                                   
                                                    @php
                                                    $dataArray = explode(",", $team->member);
                                                    $dataCount = count($dataArray);
                                                    @endphp
                                                
                                                    <tr>
                                                        <td>
                                                            <label class="form-checkbox">
                                                                <input type="checkbox">
                                                                <span class="checkbox-label"></span>
                                                            </label>
                                                        </td>
                                                        <td>{{$team->team_title}}</td>
                                                        
                                                        <td>{{$dataCount}}</td>
                                                        <td>4</td>
                                                        @foreach(DB::table('members')->get() as $r)
                                                        @if($r->id == $team->lead_id)
                                                        <td class="image-cell">
                                                            @if($r->image != NULL)
                                                            <img src="{{asset('assets/images/'.$r->image)}}" alt="Example Image">
                                                            @else
                                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTv1Tt9_33HyVMm_ZakYQy-UgsLjE00biEArg&usqp=CAU" alt="Example Image">
                                                            @endif
                                                            <div>
                                                                <div class="title">{{$r->name}}</div>
                                                            </div>
                                                        </td>
                                                        @endif
                                                        @endforeach
                                                        
                                                        <td>
                                                              <button class="btn-circle btn-tolbar" data-toggle="modal" data-target="#edit{{$team->id}}">
                                                                <img src="{{asset('assets/images/icons/edit.svg')}}" data-toggle="tooltip" data-placement="top" data-original-title="Edit">
                                                            </button>
                                                            <button class="btn-circle btn-tolbar">
                                                                <img src="{{asset('assets/images/icons/delete.svg')}}" data-toggle="tooltip" data-placement="top" data-original-title="Delete">
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    
                                                    <div class="modal fade" id="edit{{$team->id}}" tabindex="-1" role="dialog" aria-labelledby="add-team" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content" style="width: 526px !important;">
                                                                    <div class="modal-header">
                                                                        <div class="row">
                                                                            <div class="col-md-12">
                                                                                <h5 class="modal-title" id="create-epic">Update Team</h5>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <p>Lorem ipsum dummy text for printing</p>
                                                                            </div>
                                                                        </div>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                         <img src="{{asset('assets/images/icons/minus.svg')}}">
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form class="needs-validation" action="{{url('update-team-unit')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="id" value="{{$team->id}}">
                                                                            <div class="row">
                                                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                                                    <div class="form-group mb-0">
                                                                                        <input type="text" class="form-control" value="{{$team->team_title}}" name="team_title" id="team-title" required>
                                                                                        <label for="team-title">Team Tital</label>
                                                                                    </div>
                                                                                </div>
                                                                              <div class="col-md-12 col-lg-12 col-xl-12">
                                                                                    <div class="form-group mb-0">
                                                                                        <select class="form-control" name="lead_manager_team">
                                                                                            <?php foreach(DB::table('members')->where('org_user',Auth::id())->get() as $r){ ?>
                                                                                              <option @if($r->id == $team->lead_id) selected @endif value="{{ $r->id }}">{{ $r->name }}</option>
                                                                                            <?php }  ?>
                                                                                        </select>
                                                                                        <label for="lead-manager">Lead Manager</label>
                                                                                    </div>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                                                    <div class="d-flex flex-row align-items-center justify-content-between mt-4">
                                                                                        <div>
                                                                                            Organization Member
                                                                                        </div>
                                                                                        <div>
                                                                                            <input type="text" class="form-control input-sm" placeholder="Search..." name="">
                                                                                        </div>
                                                                                    </div>
                                                                                    <hr>
                                                                                </div>
                                                                                <div class="col-md-12 col-lg-12 col-xl-12 member-area">
                                                                                    @foreach(DB::table('members')->where('org_user',Auth::id())->get() as $r)
                                                                                    <div class="d-flex flex-row align-items-center justify-content-between single-member">
                                                                                        <div class="d-flex flex-row align-items-center ">
                                                                                            <div>
                                                                                                 @if($r->image != NULL)
                                                                                                <img width="45px" height="45px" src="{{asset('assets/images/'.$r->image)}}" alt="Example Image">
                                                                                                @else
                                                                                                <img width="45px" height="45px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTv1Tt9_33HyVMm_ZakYQy-UgsLjE00biEArg&usqp=CAU" alt="Example Image">
                                                                                                @endif
                                                                                                
                                                                                            </div>
                                                                                            <div class="d-flex flex-column ml-3">
                                                                                                <p>{{$r->name}}</p>
                                                                                                <small>{{$r->email}}</small>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div>
                                                                                            <input type="checkbox" @foreach(explode(',',$team->member) as $t) @if($r->id == $t) checked @endif @endforeach value="{{$r->id}}" name="member[]">
                                                                                        </div>
                                                                                    </div>
                                                                                    @endforeach
                                                                               
                                                                                </div>
                                                                                <div class="col-md-12">
                                                                                    <button class="btn btn-primary btn-lg btn-theme btn-block ripple" type="submit">Submit</button>
                                                                                </div>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div> 
                                                    @endforeach
                                                    @endif
                                                </tbody>
                                            </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end page content -->
            </div>
        </div>
    </div>
    
    
<!-- Create Business Unit -->
<!-- Create Business Unit -->
<div class="modal fade" id="add-team" tabindex="-1" role="dialog" aria-labelledby="add-team" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 526px !important;">
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="modal-title" id="create-epic">Create Team</h5>
                    </div>
                    <div class="col-md-12">
                        <p>Fill-in the details bellow</p>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <img src="{{asset('assets/images/icons/minus.svg')}}">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" action="{{url('add-team-unit')}}" method="POST">
                    @csrf
                    <input type="hidden" name="team_unit_id" value="{{$organization->id}}">
                    <div class="row">
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <input type="text" class="form-control" name="team_title" id="team-title" required>
                                <label for="team-title">Team Title</label>
                            </div>
                        </div>
                      <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="form-group mb-0">
                                <select class="form-control" name="lead_manager_team">
                                    <?php foreach(DB::table('members')->where('org_user',Auth::id())->get() as $r){ ?>
                                      <option value="{{ $r->id }}">{{ $r->name }}</option>
                                    <?php }  ?>
                                </select>
                                <label for="lead-manager">Lead Manager</label>
                            </div>
                        </div>
                        
                        <div class="col-md-12 col-lg-12 col-xl-12">
                            <div class="d-flex flex-row align-items-center justify-content-between mt-4">
                                <div>
                                    Add Users
                                </div>
                                <div>
                                    <input type="text" class="form-control input-sm" placeholder="Search..." name="">
                                </div>
                            </div>
                            <hr>
                        </div>
                        <div class="col-md-12 col-lg-12 col-xl-12 member-area">
                            @foreach(DB::table('members')->where('org_user',Auth::id())->get() as $r)
                            <div class="d-flex flex-row align-items-center justify-content-between single-member">
                                <div class="d-flex flex-row align-items-center ">
                                    <div>
                                         @if($r->image != NULL)
                                        <img width="45px" height="45px" src="{{asset('assets/images/'.$r->image)}}" alt="Example Image">
                                        @else
                                        <img width="45px" height="45px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTv1Tt9_33HyVMm_ZakYQy-UgsLjE00biEArg&usqp=CAU" alt="Example Image">
                                        @endif
                                        
                                    </div>
                                    <div class="d-flex flex-column ml-3">
                                        <p>{{$r->name}}</p>
                                        <small>{{$r->email}}</small>
                                    </div>
                                </div>
                                <div>
                                    <input type="checkbox" value="{{$r->id}}" name="member[]">
                                </div>
                            </div>
                            @endforeach
                       
                        </div>
                        <div class="col-md-12">
                            <button class="btn btn-primary btn-lg btn-theme btn-block ripple" type="submit">Create Team</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>    
    
@endsection