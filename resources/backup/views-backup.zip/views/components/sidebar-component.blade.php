<div class="aside">
    <div class="d-flex flex-column flex-shrink-0 bg-light" style="width: 100%; height: 89vh;">
        <ul class="nav nav-pills nav-flush flex-column mb-auto text-center sidebar" id="navbarSupportedContent">
            <li class="nav-item">
                <a href="{{url('/home')}}" class="nav-link active" aria-current="page" title="" data-toggle="tooltip" data-placement="right" data-original-title="Dashboard">
                    <img src="{{asset('assets/images/icons/home.svg')}}">
                </a>
            </li>
            <li>
                <a href="#panel" class="nav-link" title="" data-toggle="tooltip" data-placement="right" data-original-title="Organizations">
                    <img src="{{asset('assets/images/icons/departments.svg')}}">
                </a>
            </li>
            <div class="border-top py-2">
            </div>

            <li>
                <a href="{{url('/member')}}" class="nav-link" title="" data-toggle="tooltip" data-placement="right" data-original-title="Users">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none">
                      <path opacity="0.4" d="M10.5007 2.33325C7.44398 2.33325 4.95898 4.81825 4.95898 7.87492C4.95898 10.8733 7.30398 13.2999 10.3607 13.4049C10.454 13.3933 10.5473 13.3933 10.6173 13.4049C10.6407 13.4049 10.6523 13.4049 10.6756 13.4049C10.6873 13.4049 10.6873 13.4049 10.699 13.4049C13.6856 13.2999 16.0306 10.8733 16.0423 7.87492C16.0423 4.81825 13.5573 2.33325 10.5007 2.33325Z" fill="#787878"/>
                      <path d="M16.4271 16.5084C13.1721 14.3384 7.86378 14.3384 4.58544 16.5084C3.10378 17.5 2.28711 18.8417 2.28711 20.2767C2.28711 21.7117 3.10378 23.0417 4.57378 24.0217C6.20711 25.1184 8.35378 25.6667 10.5004 25.6667C12.6471 25.6667 14.7938 25.1184 16.4271 24.0217C17.8971 23.03 18.7138 21.7 18.7138 20.2534C18.7021 18.8184 17.8971 17.4884 16.4271 16.5084Z" fill="#787878"/>
                      <path opacity="0.4" d="M23.3209 8.56337C23.5076 10.8267 21.8976 12.81 19.6693 13.0784C19.6576 13.0784 19.6576 13.0784 19.6459 13.0784H19.6109C19.5409 13.0784 19.4709 13.0784 19.4126 13.1017C18.2809 13.16 17.2426 12.7984 16.4609 12.1334C17.6626 11.06 18.3509 9.45003 18.2109 7.70003C18.1293 6.75503 17.8026 5.8917 17.3126 5.1567C17.7559 4.93504 18.2693 4.79504 18.7943 4.74837C21.0809 4.55004 23.1226 6.25337 23.3209 8.56337Z" fill="#787878"/>
                      <path d="M25.6556 19.3549C25.5623 20.4866 24.8389 21.4666 23.6256 22.1316C22.4589 22.7732 20.9889 23.0766 19.5306 23.0416C20.3706 22.2832 20.8606 21.3382 20.9539 20.3349C21.0706 18.8882 20.3823 17.4999 19.0056 16.3916C18.2239 15.7732 17.3139 15.2832 16.3223 14.9216C18.9006 14.1749 22.1439 14.6766 24.1389 16.2866C25.2123 17.1499 25.7606 18.2349 25.6556 19.3549Z" fill="#787878"/>
                    </svg>
                </a>
            </li>
            <!-- <li>
                <a href="#" class="nav-link" title="" data-toggle="tooltip" data-placement="right" data-original-title="Customers">
                    <img src="{{asset('assets/images/icons/document.svg')}}">
                </a>
            </li> -->
            <li>
                <a href="{{ route('logout') }}"  onclick="event.preventDefault();
                document.getElementById('logout-form').submit();" class="nav-link" title="" data-toggle="tooltip" data-placement="right" data-original-title="Logout">
                    <img src="{{asset('assets/images/icons/logout.svg')}}">
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </li>
        </ul>
        <div class="align-items-center mx-auto mb-3">
            <button class="btn-circle btn-xl btn-help">
                <img src="{{asset('assets/images/icons/help.svg')}}">
            </button>
        </div>
    </div>
</div>

